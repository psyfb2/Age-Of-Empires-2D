#include "header.h"
#include "BaseState.h"

BaseState::BaseState(Psyfb2* engine) :
	engine(engine)
{
}


BaseState::~BaseState()
{
}
